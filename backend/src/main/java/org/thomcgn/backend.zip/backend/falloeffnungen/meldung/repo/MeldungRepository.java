package org.thomcgn.backend.falloeffnungen.meldung.repo;

import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import org.thomcgn.backend.falloeffnungen.meldung.model.Meldung;

import java.util.List;
import java.util.Optional;

public interface MeldungRepository extends JpaRepository<Meldung, Long> {

    @Query("select m from Meldung m where m.falleroeffnung.id = :fallId and m.current = true")
    Optional<Meldung> findCurrentByFallId(@Param("fallId") Long fallId);

    @Query("select max(m.versionNo) from Meldung m where m.falleroeffnung.id = :fallId")
    Integer findMaxVersionNo(@Param("fallId") Long fallId);

    Optional<Meldung> findTopByFalleroeffnung_IdOrderByVersionNoDesc(Long fallId);

    @Query("select m from Meldung m where m.falleroeffnung.id = :fallId order by m.versionNo desc")
    List<Meldung> listByFall(@Param("fallId") Long fallId);

    @Modifying
    @Query("update Meldung m set m.current = false where m.falleroeffnung.id = :fallId and m.id <> :keepId")
    int clearCurrentByFallIdExcept(@Param("fallId") Long fallId, @Param("keepId") Long keepId);
}