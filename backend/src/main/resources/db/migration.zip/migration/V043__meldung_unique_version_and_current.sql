-- V2026_03_02_001__meldung_unique_version_and_current.sql
-- PostgreSQL
--
-- Enforces:
-- 1) version number unique per Fallöffnung: (falleroeffnung_id, version_no)
-- 2) only one "current=true" Meldung per Fallöffnung: UNIQUE (falleroeffnung_id) WHERE current = true
--
-- IMPORTANT:
-- If you already have duplicates, these index creations will FAIL.
-- In that case, run the "duplicate finder" queries at the bottom first and fix data.

BEGIN;

-- (Optional but recommended) Ensure predictable NOT NULL / defaults
-- Uncomment if your schema allows it and you want stronger guarantees.
-- ALTER TABLE meldung ALTER COLUMN current SET DEFAULT false;
-- ALTER TABLE meldung ALTER COLUMN current SET NOT NULL;
-- ALTER TABLE meldung ALTER COLUMN version_no SET NOT NULL;

-- 1) Unique version per fall (falleroeffnung)
CREATE UNIQUE INDEX IF NOT EXISTS ux_meldung_fall_versionno
    ON meldung (falleroeffnung_id, version_no);

-- 2) Only one current per fall (partial unique index)
CREATE UNIQUE INDEX IF NOT EXISTS ux_meldung_fall_current_true
    ON meldung (falleroeffnung_id)
    WHERE current IS TRUE;

COMMIT;

-- -------------------------------------------------------------------
-- DUPLICATE FINDERS (run manually if index creation fails)
-- -------------------------------------------------------------------

-- -- A) Multiple current=true per fall
-- SELECT falleroeffnung_id, COUNT(*) AS cnt, ARRAY_AGG(id ORDER BY id) AS meldung_ids
-- FROM meldung
-- WHERE current IS TRUE
-- GROUP BY falleroeffnung_id
-- HAVING COUNT(*) > 1;

-- -- B) Duplicate version numbers per fall
-- SELECT falleroeffnung_id, version_no, COUNT(*) AS cnt, ARRAY_AGG(id ORDER BY id) AS meldung_ids
-- FROM meldung
-- GROUP BY falleroeffnung_id, version_no
-- HAVING COUNT(*) > 1;