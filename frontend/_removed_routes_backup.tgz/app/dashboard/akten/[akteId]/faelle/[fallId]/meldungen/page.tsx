"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { AuthGate } from "@/components/AuthGate";
import { TopbarConnected as Topbar } from "@/components/layout/TopbarConnected";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { listMeldungenByFallId, type FallMeldungListItem } from "@/lib/meldungen/listing";

function toneForStatus(status: string): "neutral" | "info" | "success" | "warning" {
    if (status === "ENTWURF") return "warning";
    if (status === "ABGESCHLOSSEN") return "success";
    return "neutral";
}

function labelForStatus(status: string) {
    if (status === "ENTWURF") return "Entwurf";
    if (status === "ABGESCHLOSSEN") return "Abgeschlossen";
    return status;
}

function toneForType(type: string): "neutral" | "info" | "success" {
    if (type === "ERSTMELDUNG") return "info";
    if (type === "MELDUNG") return "success";
    return "neutral";
}

function labelForType(type: string) {
    if (type === "ERSTMELDUNG") return "Erstmeldung";
    if (type === "MELDUNG") return "Meldung";
    if (type === "KORREKTUR") return "Korrektur";
    return type;
}

export default function FallMeldungenInAktePage({ params }: { params: { akteId: string; fallId: string } }) {
    const router = useRouter();
    const akteId = params.akteId;
    const fallId = Number(params.fallId);

    const [q, setQ] = React.useState("");
    const [data, setData] = React.useState<FallMeldungListItem[] | null>(null);
    const [loading, setLoading] = React.useState(false);
    const [err, setErr] = React.useState<string | null>(null);

    const load = React.useCallback(async () => {
        setLoading(true);
        setErr(null);

        try {
            if (!Number.isFinite(fallId)) throw new Error("Ungültige Fall-ID");
            const res = await listMeldungenByFallId(fallId);

            const sorted = [...res].sort((a, b) => {
                if (a.current !== b.current) return a.current ? -1 : 1;
                return (b.versionNo ?? 0) - (a.versionNo ?? 0);
            });

            setData(sorted);
        } catch (e: any) {
            setErr(e?.message || "Konnte Meldungen nicht laden.");
            setData(null);
        } finally {
            setLoading(false);
        }
    }, [fallId]);

    React.useEffect(() => {
        load();
    }, [load]);

    const items = React.useMemo(() => {
        const list = data ?? [];
        const qq = q.trim().toLowerCase();
        if (!qq) return list;

        return list.filter((m) => {
            const hay = [
                String(m.id),
                String(m.versionNo),
                m.status,
                m.type,
                m.createdByDisplayName,
                m.createdAt,
                m.supersedesId == null ? "" : String(m.supersedesId),
                m.correctsId == null ? "" : String(m.correctsId),
            ]
                .join(" ")
                .toLowerCase();

            return hay.includes(qq);
        });
    }, [data, q]);

    const current = React.useMemo(() => (data ?? []).find((x) => x.current), [data]);

    return (
        <AuthGate>
            <div className="min-h-screen bg-background">
                <Topbar
                    title={`Meldungen · Fall ${Number.isFinite(fallId) ? fallId : "—"}`}
                    onSearch={(val) => setQ(val)}
                />

                <div className="mx-auto w-full max-w-6xl space-y-4 p-4 md:p-6">
                    <div className="flex items-center justify-between gap-3">
                        <div className="text-sm text-muted-foreground">
                            <Link href={`/dashboard/akten/${akteId}`} className="underline underline-offset-4">
                                ← zurück zur Akte
                            </Link>
                            <span className="ml-3">Akte #{akteId} · Fall #{Number.isFinite(fallId) ? fallId : "—"}</span>
                            {current ? (
                                <span className="ml-3">
                  · Current: <strong>Meldung #{current.id}</strong> · V{current.versionNo}
                </span>
                            ) : null}
                        </div>

                        <div className="flex items-center gap-2">
                            <Button variant="secondary" onClick={() => load()} disabled={loading}>
                                Aktualisieren
                            </Button>

                            {current ? (
                                <Button
                                    onClick={() => router.push(`/dashboard/akten/${akteId}/faelle/${fallId}/meldungen/${current.id}`)}
                                    disabled={loading}
                                >
                                    Current öffnen
                                </Button>
                            ) : null}
                        </div>
                    </div>

                    {err ? (
                        <div className="rounded-2xl border border-destructive/20 bg-destructive/10 p-3 text-sm text-destructive">{err}</div>
                    ) : null}

                    <Card>
                        <CardHeader className="flex flex-row items-center justify-between">
                            <div className="text-sm font-semibold">Liste</div>
                            <div className="text-xs text-muted-foreground">{loading ? "…" : `${items.length} Einträge`}</div>
                        </CardHeader>

                        <CardContent className="space-y-2">
                            {!items.length ? (
                                <div className="rounded-2xl border border-border bg-muted p-4 text-sm text-muted-foreground">
                                    Keine Meldungen zu diesem Fall vorhanden.
                                </div>
                            ) : (
                                <div className="space-y-2">
                                    {items.map((m) => (
                                        <button
                                            key={m.id}
                                            onClick={() => router.push(`/dashboard/akten/${akteId}/faelle/${fallId}/meldungen/${m.id}`)}
                                            className="w-full rounded-2xl border border-border bg-card p-3 text-left transition hover:bg-accent"
                                        >
                                            <div className="flex items-start justify-between gap-3">
                                                <div className="min-w-0">
                                                    <div className="truncate text-sm font-semibold">
                                                        Meldung #{m.id} · V{m.versionNo}
                                                    </div>
                                                    <div className="mt-1 text-xs text-muted-foreground">
                                                        {new Date(m.createdAt).toLocaleString()} · {m.createdByDisplayName}
                                                    </div>
                                                </div>

                                                <div className="flex items-center gap-2">
                                                    {m.current ? <Badge tone="info">current</Badge> : null}
                                                    <Badge tone={toneForType(m.type)}>{labelForType(m.type)}</Badge>
                                                    <Badge tone={toneForStatus(m.status)}>{labelForStatus(m.status)}</Badge>
                                                </div>
                                            </div>

                                            <div className="mt-2 text-xs text-muted-foreground">
                                                supersedes: {m.supersedesId ?? "—"} · corrects: {m.correctsId ?? "—"}
                                            </div>
                                        </button>
                                    ))}
                                </div>
                            )}
                        </CardContent>
                    </Card>
                </div>
            </div>
        </AuthGate>
    );
}