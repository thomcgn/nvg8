"use client";

import "@/components/meldungen/meldungen.css";
import Link from "next/link";
import { useEffect, useState } from "react";
import { MeldungenApi, MeldungVersion } from "@/lib/meldungen/api";

export default function MeldungVersionPage({ params }: { params: { meldungId: string; versionId: string } }) {
    const { meldungId, versionId } = params;
    const [v, setV] = useState<MeldungVersion | null>(null);
    const [err, setErr] = useState<string | null>(null);

    useEffect(() => {
        (async () => {
            setErr(null);
            try {
                const vv = await MeldungenApi.getVersion(versionId);
                setV(vv);
            } catch (e: any) {
                setErr(e?.message ?? "Fehler");
            }
        })();
    }, [versionId]);

    if (err) return <div className="mPage"><div className="mError">{err}</div></div>;
    if (!v) return <div className="mPage">Lade Version…</div>;

    return (
        <div className="mPage">
            <header className="mHeader">
                <div>
                    <div className="mSub"><Link href={`/dashboard/falloeffnungen/meldungen/${meldungId}`}>← zurück zur Meldung</Link></div>
                    <h1>Version V{v.versionNumber}</h1>
                    <div className="mSub">State: {v.state}</div>
                </div>
                <div className="mActions">
                    <Link className="mBtn" href={`/dashboard/falloeffnungen/meldungen/${meldungId}/compare/${versionId}/${versionId}`}>
                        Vergleichen
                    </Link>
                </div>
            </header>

            <section className="mCard">
                <h2>Inhalt (read-only)</h2>
                <pre style={{ whiteSpace: "pre-wrap" }}>{JSON.stringify(v.data, null, 2)}</pre>
            </section>
        </div>
    );
}