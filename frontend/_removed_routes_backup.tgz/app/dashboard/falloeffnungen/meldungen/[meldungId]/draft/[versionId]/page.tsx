"use client";

import "@/components/meldungen/meldungen.css";
import Link from "next/link";
import { useEffect, useState } from "react";
import { MeldungenApi, ChangeReason, MeldungVersion } from "@/lib/meldungen/api";

function requiresInfoEffectiveAt(reason: ChangeReason) {
    return reason === "nachtrag" || reason === "update" || reason === "reassessment";
}

export default function MeldungDraftPage({ params }: { params: { meldungId: string; versionId: string } }) {
    const { meldungId, versionId } = params;

    const [v, setV] = useState<MeldungVersion | null>(null);
    const [draft, setDraft] = useState<any | null>(null);
    const [err, setErr] = useState<string | null>(null);
    const [saving, setSaving] = useState(false);

    const [changeReason, setChangeReason] = useState<ChangeReason>("fix");
    const [infoEffectiveAt, setInfoEffectiveAt] = useState<string>("");
    const [reasonText, setReasonText] = useState<string>("");

    async function load() {
        setErr(null);
        try {
            const vv = await MeldungenApi.getVersion(versionId);
            setV(vv);
            setDraft(vv.data);

            setChangeReason((vv.changeReason ?? "fix") as ChangeReason);
            setInfoEffectiveAt(vv.infoEffectiveAt ? toLocalDatetimeInput(vv.infoEffectiveAt) : "");
            setReasonText(vv.reasonText ?? "");
        } catch (e: any) {
            setErr(e?.message ?? "Fehler");
        }
    }

    useEffect(() => { load(); /* eslint-disable-next-line */ }, [versionId]);

    async function save() {
        if (!draft) return;
        setSaving(true);
        setErr(null);
        try {
            await MeldungenApi.patchDraft(versionId, {
                data: draft,
                changeReason,
                infoEffectiveAt: infoEffectiveAt ? fromLocalDatetimeInput(infoEffectiveAt) : null,
                reasonText: reasonText || null,
            });
        } catch (e: any) {
            setErr(e?.message ?? "Fehler beim Speichern");
        } finally {
            setSaving(false);
        }
    }

    async function finalize() {
        setErr(null);

        if (!changeReason) {
            setErr("Änderungsgrund ist erforderlich.");
            return;
        }
        if (requiresInfoEffectiveAt(changeReason) && !infoEffectiveAt) {
            setErr("Bitte Zeitpunkt der Kenntniserlangung angeben.");
            return;
        }

        setSaving(true);
        try {
            // ensure latest content saved
            await save();
            await MeldungenApi.finalizeDraft(versionId, {
                changeReason,
                infoEffectiveAt: infoEffectiveAt ? fromLocalDatetimeInput(infoEffectiveAt) : undefined,
                reasonText: reasonText || undefined,
            });

            window.location.href = `/dashboard/falloeffnungen/meldungen/${meldungId}`;
        } catch (e: any) {
            setErr(e?.message ?? "Fehler beim Abschließen");
        } finally {
            setSaving(false);
        }
    }

    async function discard() {
        setSaving(true);
        setErr(null);
        try {
            await MeldungenApi.discardDraft(versionId);
            window.location.href = `/dashboard/falloeffnungen/meldungen/${meldungId}`;
        } catch (e: any) {
            setErr(e?.message ?? "Fehler beim Verwerfen");
        } finally {
            setSaving(false);
        }
    }

    if (err && !v) {
        return <div className="mPage"><div className="mError">{err}</div></div>;
    }

    if (!v || !draft) {
        return <div className="mPage">Lade Entwurf…</div>;
    }

    return (
        <div className="mPage">
            <header className="mHeader">
                <div>
                    <div className="mSub">
                        <Link href={`/dashboard/falloeffnungen/meldungen/${meldungId}`}>← zurück zur Meldung</Link>
                    </div>
                    <h1>Neue Version (Entwurf)</h1>
                    <div className="mSub">
                        Entwurf V{v.versionNumber} {v.basedOnVersionId ? "• basiert auf vorheriger Version" : ""}
                    </div>
                </div>

                <div className="mActions">
                    <button className="mBtn" onClick={save} disabled={saving}>Entwurf speichern</button>
                    <button className="mBtn mBtnPrimary" onClick={finalize} disabled={saving}>Version abschließen</button>
                    <button className="mBtn" onClick={discard} disabled={saving}>Verwerfen</button>
                </div>
            </header>

            {err && <div className="mError">{err}</div>}

            <section className="mCard">
                <h2>Änderungsangaben</h2>

                <div className="mFormRow">
                    <label>Änderungsgrund (Pflicht)</label>
                    <select value={changeReason} onChange={(e) => setChangeReason(e.target.value as ChangeReason)}>
                        <option value="fix">Korrektur (Fehlerberichtigung)</option>
                        <option value="nachtrag">Nachtrag (neue Information)</option>
                        <option value="update">Sachlage geändert (Update)</option>
                        <option value="reassessment">Fachliche Neubewertung</option>
                    </select>
                </div>

                {requiresInfoEffectiveAt(changeReason) && (
                    <div className="mFormRow">
                        <label>Zeitpunkt Kenntniserlangung (Pflicht)</label>
                        <input type="datetime-local" value={infoEffectiveAt} onChange={(e) => setInfoEffectiveAt(e.target.value)} />
                        <div className="mHint">Wann wurde die Information bekannt (z. B. Telefonat mit Mutter/Arzt)?</div>
                    </div>
                )}

                <div className="mFormRow">
                    <label>Kurzbegründung (empfohlen, bei kritischen Änderungen ggf. Pflicht)</label>
                    <textarea rows={3} value={reasonText} onChange={(e) => setReasonText(e.target.value)} />
                </div>
            </section>

            <section className="mCard">
                <h2>Gefährdungseinschätzung</h2>

                <div className="mFormRow">
                    <label>Gefährdung</label>
                    <select
                        value={draft?.assessment?.riskLevel ?? ""}
                        onChange={(e) => setDraft(setPath(draft, ["assessment", "riskLevel"], e.target.value))}
                    >
                        <option value="">—</option>
                        <option value="niedrig">niedrig</option>
                        <option value="mittel">mittel</option>
                        <option value="hoch">hoch</option>
                        <option value="akut">akut</option>
                    </select>
                </div>

                <div className="mFormRow">
                    <label>Begründung</label>
                    <textarea
                        rows={4}
                        value={draft?.assessment?.rationale ?? ""}
                        onChange={(e) => setDraft(setPath(draft, ["assessment", "rationale"], e.target.value))}
                    />
                </div>

                <h2>Kontaktverlauf</h2>
                <button
                    className="mBtn"
                    type="button"
                    onClick={() => setDraft(addContact(draft))}
                >
                    Kontakt hinzufügen
                </button>

                <div style={{ marginTop: 12 }}>
                    {(draft?.facts?.contacts ?? []).map((c: any, idx: number) => (
                        <div key={c.id} className="mCard" style={{ marginTop: 10 }}>
                            <div className="mFormRow">
                                <label>Partei</label>
                                <input
                                    value={c.party ?? ""}
                                    onChange={(e) => {
                                        const next = structuredClone(draft);
                                        next.facts ??= {};
                                        next.facts.contacts ??= [];
                                        next.facts.contacts[idx].party = e.target.value;
                                        setDraft(next);
                                    }}
                                />
                            </div>
                            <div className="mFormRow">
                                <label>Ergebnis</label>
                                <select
                                    value={c.outcome ?? "nicht_erreicht"}
                                    onChange={(e) => {
                                        const next = structuredClone(draft);
                                        next.facts.contacts[idx].outcome = e.target.value;
                                        setDraft(next);
                                    }}
                                >
                                    <option value="erreicht">erreicht</option>
                                    <option value="nicht_erreicht">nicht erreicht</option>
                                    <option value="rueckruf_offen">Rückruf offen</option>
                                    <option value="abgebrochen">abgebrochen</option>
                                </select>
                            </div>
                            <div className="mFormRow">
                                <label>Notiz</label>
                                <textarea
                                    rows={2}
                                    value={c.note ?? ""}
                                    onChange={(e) => {
                                        const next = structuredClone(draft);
                                        next.facts.contacts[idx].note = e.target.value;
                                        setDraft(next);
                                    }}
                                />
                            </div>
                        </div>
                    ))}
                </div>
            </section>

            <div className="mStickyBar">
                <button className="mBtn" onClick={save} disabled={saving}>Entwurf speichern</button>
                <button className="mBtn mBtnPrimary" onClick={finalize} disabled={saving}>Abschließen</button>
            </div>
        </div>
    );
}

function setPath(obj: any, path: string[], value: any) {
    const next = structuredClone(obj ?? {});
    let cur = next;
    for (let i = 0; i < path.length - 1; i++) {
        cur[path[i]] = cur[path[i]] ?? {};
        cur = cur[path[i]];
    }
    cur[path[path.length - 1]] = value;
    return next;
}

function addContact(draft: any) {
    const next = structuredClone(draft ?? {});
    next.facts ??= {};
    next.facts.contacts ??= [];
    next.facts.contacts.push({
        id: `cnt_${Math.random().toString(16).slice(2)}`,
        contactedAt: new Date().toISOString(),
        party: "",
        outcome: "nicht_erreicht",
        note: "",
    });
    return next;
}

// helper: server gives ISO; datetime-local expects "YYYY-MM-DDTHH:mm"
function toLocalDatetimeInput(iso: string) {
    const d = new Date(iso);
    const pad = (n: number) => String(n).padStart(2, "0");
    return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}
function fromLocalDatetimeInput(v: string) {
    // treat as local time
    const d = new Date(v);
    return d.toISOString();
}