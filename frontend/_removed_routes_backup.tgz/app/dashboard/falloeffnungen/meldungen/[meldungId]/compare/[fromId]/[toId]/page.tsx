"use client";

import "@/components/meldungen/meldungen.css";
import Link from "next/link";
import { useEffect, useState } from "react";
import { MeldungenApi, CompareResponse } from "@/lib/meldungen/api";

export default function MeldungComparePage({ params }: { params: { meldungId: string; fromId: string; toId: string } }) {
    const { meldungId, fromId, toId } = params;
    const [cmp, setCmp] = useState<CompareResponse | null>(null);
    const [err, setErr] = useState<string | null>(null);

    useEffect(() => {
        (async () => {
            setErr(null);
            try {
                const c = await MeldungenApi.compare(fromId, toId);
                setCmp(c);
            } catch (e: any) {
                setErr(e?.message ?? "Fehler");
            }
        })();
    }, [fromId, toId]);

    if (err) return <div className="mPage"><div className="mError">{err}</div></div>;
    if (!cmp) return <div className="mPage">Lade Vergleich…</div>;

    return (
        <div className="mPage">
            <header className="mHeader">
                <div>
                    <div className="mSub"><Link href={`/dashboard/falloeffnungen/meldungen/${meldungId}`}>← zurück zur Meldung</Link></div>
                    <h1>Vergleich</h1>
                    <div className="mSub">Von {fromId} → {toId}</div>
                </div>
            </header>

            <section className="mCard">
                <h2>Geänderte Felder</h2>
                <ul>
                    {cmp.changedFields.map((p) => <li key={p}>{p}</li>)}
                </ul>
            </section>

            <section className="mCard">
                <h2>Änderungen</h2>

                <h3>Updated</h3>
                <ul>
                    {cmp.diff.updated.map((u, i) => (
                        <li key={i}>
                            <strong>{u.path}</strong>
                            <div><em>vorher:</em> {renderInline(u.before)}</div>
                            <div><em>nachher:</em> {renderInline(u.after)}</div>
                        </li>
                    ))}
                </ul>

                <h3>Added</h3>
                <ul>
                    {cmp.diff.added.map((a, i) => (
                        <li key={i}>
                            <strong>{a.path}</strong> → {renderInline(a.value)}
                        </li>
                    ))}
                </ul>

                <h3>Removed</h3>
                <ul>
                    {cmp.diff.removed.map((r, i) => (
                        <li key={i}>
                            <strong>{r.path}</strong> → {renderInline(r.value)}
                        </li>
                    ))}
                </ul>
            </section>
        </div>
    );
}

function renderInline(v: any) {
    if (v == null) return "—";
    if (typeof v === "string" || typeof v === "number" || typeof v === "boolean") return String(v);
    return <code>{JSON.stringify(v)}</code>;
}