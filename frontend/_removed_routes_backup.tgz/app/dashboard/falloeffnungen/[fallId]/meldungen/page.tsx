"use client";

import "@/components/meldungen/meldungen.css";
import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { MeldungenApi } from "@/lib/meldungen/api";
import type { FallMeldungListItem } from "@/lib/meldungen/api";

function statusBadge(status: string) {
    if (status === "ENTWURF") return "Entwurf";
    if (status === "ABGESCHLOSSEN") return "Abgeschlossen";
    return status;
}

function typeBadge(type: string) {
    if (type === "ERSTMELDUNG") return "Erstmeldung";
    if (type === "MELDUNG") return "Meldung";
    if (type === "KORREKTUR") return "Korrektur";
    return type;
}

export default function FallMeldungenPage({ params }: { params: { fallId: string } }) {
    const fallId = params.fallId;

    const [items, setItems] = useState<FallMeldungListItem[] | null>(null);
    const [err, setErr] = useState<string | null>(null);

    useEffect(() => {
        (async () => {
            setErr(null);
            try {
                const list = await MeldungenApi.listByFallId(fallId);
                // sort: current first, then by version desc
                list.sort((a, b) => {
                    if (a.current !== b.current) return a.current ? -1 : 1;
                    return (b.versionNo ?? 0) - (a.versionNo ?? 0);
                });
                setItems(list);
            } catch (e: any) {
                setErr(e?.message ?? "Fehler beim Laden");
                setItems([]);
            }
        })();
    }, [fallId]);

    const current = useMemo(() => (items ?? []).find((x) => x.current), [items]);
    const drafts = useMemo(() => (items ?? []).filter((x) => x.status === "ENTWURF"), [items]);

    return (
        <div className="mPage">
            <header className="mHeader">
                <div>
                    <div className="mSub">
                        <Link href="/dashboard/falloeffnungen">← zurück</Link>
                    </div>
                    <h1>Meldungen zu Fall {fallId}</h1>
                    <div className="mSub">
                        {current ? (
                            <>Aktuell: <strong>ID {current.id}</strong> • V{current.versionNo} • {typeBadge(current.type)} • {statusBadge(current.status)}</>
                        ) : (
                            <>Keine aktuelle Meldung markiert</>
                        )}
                    </div>
                </div>

                <div className="mActions">
                    {/* Quick open current */}
                    {current && (
                        <Link className="mBtn mBtnPrimary" href={`/dashboard/falloeffnungen/meldungen/${current.id}`}>
                            Aktuelle öffnen
                        </Link>
                    )}
                    {/* Quick open first draft */}
                    {drafts[0] && (
                        <Link className="mBtn" href={`/dashboard/falloeffnungen/meldungen/${drafts[0].id}`}>
                            Entwurf öffnen
                        </Link>
                    )}
                </div>
            </header>

            {err && <div className="mError">{err}</div>}
            {!items && <div>Lade…</div>}

            {items && (
                <div className="mStack">
                    <section className="mCard">
                        <div className="mCardHeader">
                            <h2>Übersicht</h2>
                            <div className="mBadge mBadgeSoft">{items.length} Einträge</div>
                        </div>

                        {(items.length === 0) ? (
                            <div>Keine Meldungen vorhanden.</div>
                        ) : (
                            <div className="mTimeline">
                                {items.map((it) => (
                                    <div key={it.id} className="mTimelineItem">
                                        <div className="mTimelineTop">
                                            {it.current && <div className="mBadge">current</div>}
                                            <div className="mBadge mBadgeSoft">{typeBadge(it.type)}</div>
                                            <div className="mBadge mBadgeSoft">{statusBadge(it.status)}</div>

                                            <div>
                                                <strong>ID {it.id}</strong> • V{it.versionNo} • {new Date(it.createdAt).toLocaleString()} • {it.createdByDisplayName}
                                            </div>
                                        </div>

                                        <div className="mSummaryText">
                                            {it.supersedesId != null && <span>supersedes: {it.supersedesId} </span>}
                                            {it.correctsId != null && <span>• corrects: {it.correctsId}</span>}
                                            {it.supersedesId == null && it.correctsId == null && <span>—</span>}
                                        </div>

                                        <div className="mTimelineActions">
                                            <Link className="mBtn mBtnPrimary" href={`/dashboard/falloeffnungen/meldungen/${it.id}`}>
                                                Öffnen
                                            </Link>

                                            {/* Wenn du willst: Compare gegen current direkt */}
                                            {current && current.id !== it.id && (
                                                <Link className="mBtn" href={`/dashboard/falloeffnungen/meldungen/${current.id}/compare/${it.id}/${current.id}`}>
                                                    Mit aktueller vergleichen
                                                </Link>
                                            )}
                                        </div>
                                    </div>
                                ))}
                            </div>
                        )}
                    </section>
                </div>
            )}

            {items && (
                <div className="mStickyBar">
                    {current ? (
                        <Link className="mBtn mBtnPrimary" href={`/dashboard/falloeffnungen/meldungen/${current.id}`}>
                            Aktuelle öffnen
                        </Link>
                    ) : (
                        <Link className="mBtn mBtnPrimary" href={`/dashboard/falloeffnungen`}>
                            Zurück
                        </Link>
                    )}
                    <Link className="mBtn" href={`/dashboard/falloeffnungen/meldungen`}>
                        ID-Picker
                    </Link>
                </div>
            )}
        </div>
    );
}