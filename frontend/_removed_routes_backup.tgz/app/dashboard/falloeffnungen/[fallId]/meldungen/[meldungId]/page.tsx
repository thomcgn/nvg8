"use client";

import "@/components/meldungen/meldungen.css";
import Link from "next/link";
import { useEffect, useState } from "react";
import { MeldungenApi, MeldungDetail, ChangeReason } from "@/lib/meldungen/api";
import ChangeReasonModal from "@/components/meldungen/ChangeReasonModal";

function badgeLabel(reason?: ChangeReason | null) {
    switch (reason) {
        case "fix": return "Korrektur";
        case "nachtrag": return "Nachtrag";
        case "update": return "Sachlage geändert";
        case "reassessment": return "Neubewertung";
        default: return "Original";
    }
}

export default function MeldungDetailPage({ params }: { params: { meldungId: string } }) {
    const meldungId = params.meldungId;

    const [data, setData] = useState<MeldungDetail | null>(null);
    const [err, setErr] = useState<string | null>(null);
    const [busy, setBusy] = useState(false);
    const [modalOpen, setModalOpen] = useState(false);

    async function load() {
        setErr(null);
        try {
            const d = await MeldungenApi.getDetail(meldungId);
            setData(d as any);
        } catch (e: any) {
            setErr(e?.message ?? "Fehler");
        }
    }

    useEffect(() => { load(); /* eslint-disable-next-line */ }, [meldungId]);

    function openNewVersionFlow() {
        if (!data) return;
        // If draft exists, go straight there (no new draft & no modal needed)
        if (data.draft?.versionId) {
            window.location.href = `/dashboard/falloeffnungen/meldungen/${meldungId}/draft/${data.draft.versionId}`;
            return;
        }
        setModalOpen(true);
    }

    async function onConfirmMeta(meta: { changeReason: ChangeReason; infoEffectiveAt?: string; reasonText?: string }) {
        setModalOpen(false);
        setBusy(true);
        setErr(null);

        try {
            const { versionId } = await MeldungenApi.createDraft(meldungId);

            // Immediately store meta on the draft (so editor already shows it)
            await MeldungenApi.patchDraft(versionId, {
                changeReason: meta.changeReason,
                infoEffectiveAt: meta.infoEffectiveAt ?? null,
                reasonText: meta.reasonText ?? null,
            });

            window.location.href = `/dashboard/falloeffnungen/meldungen/${meldungId}/draft/${versionId}`;
        } catch (e: any) {
            setErr(e?.message ?? "Fehler");
        } finally {
            setBusy(false);
        }
    }

    return (
        <div className="mPage">
            <header className="mHeader">
                <div>
                    <div className="mSub">
                        <Link href="/dashboard/falloeffnungen">← zurück</Link>
                    </div>
                    <h1>Meldung</h1>
                    {data?.current && (
                        <div className="mSub">
                            Aktuelle Version: V{data.current.versionNumber}
                            {data.current.finalizedAt ? ` • Stand: ${new Date(data.current.finalizedAt).toLocaleString()}` : ""}
                        </div>
                    )}
                </div>

                <div className="mActions">
                    <button className="mBtn mBtnPrimary" onClick={openNewVersionFlow} disabled={busy || !data}>
                        Neue Version erstellen
                    </button>
                </div>
            </header>

            {err && <div className="mError">{err}</div>}
            {!data && <div>Lade…</div>}

            {data && (
                <div className="mGrid2">
                    <section className="mCard">
                        <div className="mCardHeader">
                            <div>
                                <div className="mBadge">Aktuell</div>
                                <h2>Aktueller Stand</h2>
                            </div>
                            <div className="mBadge mBadgeSoft">{badgeLabel(data.current.changeReason)}</div>
                        </div>

                        {data.draft && (
                            <div className="mBanner">
                                Entwurf V{data.draft.versionNumber} vorhanden (von {data.draft.createdByName}, {new Date(data.draft.createdAt).toLocaleString()}).
                                <div className="mBannerActions">
                                    <Link className="mBtn" href={`/dashboard/falloeffnungen/meldungen/${meldungId}/draft/${data.draft.versionId}`}>
                                        Entwurf öffnen
                                    </Link>
                                </div>
                            </div>
                        )}

                        <CurrentSummary data={data.current.data} />

                        <div style={{ marginTop: 16 }}>
                            <button className="mBtn mBtnPrimary" onClick={openNewVersionFlow} disabled={busy}>
                                Neue Version erstellen
                            </button>
                        </div>
                    </section>

                    <section className="mCard">
                        <div className="mCardHeader">
                            <h2>Historie</h2>
                        </div>

                        <div className="mTimeline" id="history">
                            {data.timeline.map((it) => (
                                <div key={it.id} className="mTimelineItem">
                                    <div className="mTimelineTop">
                                        <div className="mBadge mBadgeSoft">{badgeLabel(it.changeReason)}</div>
                                        <div>
                                            <strong>V{it.versionNumber}</strong> • {new Date(it.createdAt).toLocaleString()} • {it.createdByName}
                                        </div>
                                    </div>
                                    {it.changeSummary && <div className="mSummaryText">{it.changeSummary}</div>}
                                    <div className="mTimelineActions">
                                        <Link className="mBtn" href={`/dashboard/falloeffnungen/meldungen/${meldungId}/version/${it.id}`}>
                                            Details
                                        </Link>
                                        {it.id !== data.current.id && (
                                            <Link className="mBtn" href={`/dashboard/falloeffnungen/meldungen/${meldungId}/compare/${it.id}/${data.current.id}`}>
                                                Mit aktueller vergleichen
                                            </Link>
                                        )}
                                    </div>
                                </div>
                            ))}
                        </div>
                    </section>
                </div>
            )}

            {data && (
                <div className="mStickyBar">
                    <button className="mBtn mBtnPrimary" onClick={openNewVersionFlow} disabled={busy}>
                        Neue Version
                    </button>
                    <a className="mBtn" href="#history">Historie</a>
                    {data.timeline.length > 1 && (
                        <Link className="mBtn" href={`/dashboard/falloeffnungen/meldungen/${meldungId}/compare/${data.timeline[1]?.id}/${data.current.id}`}>
                            Vergleichen
                        </Link>
                    )}
                </div>
            )}

            <ChangeReasonModal
                open={modalOpen}
                title="Neue Version: Änderungsangaben"
                onClose={() => setModalOpen(false)}
                onConfirm={onConfirmMeta}
            />
        </div>
    );
}

function CurrentSummary({ data }: { data: any }) {
    const risk = data?.assessment?.riskLevel;
    const receivedAt = data?.source?.receivedAt;
    const rationale = data?.assessment?.rationale;

    return (
        <div>
            <div className="mSummaryRow">
                <div className="mLabel">Eingang</div>
                <div>{receivedAt ? new Date(receivedAt).toLocaleString() : "—"}</div>
            </div>
            <div className="mSummaryRow">
                <div className="mLabel">Gefährdung</div>
                <div>{risk ?? "—"}</div>
            </div>
            <div className="mSummaryRow">
                <div className="mLabel">Begründung</div>
                <div>{rationale ?? "—"}</div>
            </div>
        </div>
    );
}